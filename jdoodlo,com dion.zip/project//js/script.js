
    document.getElementById("loginForm").addEventListener('submit', function(event) {
      event.preventDefault();
      
      var username = document.getElementById('username').value.trim();
      var password = document.getElementById('password').value.trim();
      var errorMessage = document.getElementById('error-message');
      
      
      errorMessage.textContent = '';
      
      
      if (!username || !password) {
        errorMessage.textContent = 'Silakan isi username dan password!';
        return;
      }
      
      
      console.log('Login attempted with:', {username, password});
      
      
      if (username === "admin" && password === "12345") {
        errorMessage.textContent = '';
        alert('Login berhasil!');
        
      } else {
        errorMessage.textContent = 'Username atau password salah!';
      }
    });
 